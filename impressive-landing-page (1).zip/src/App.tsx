import { motion } from 'motion/react';
import { ArrowRight, Sparkles, Zap, Shield, Globe, Play, Menu } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen relative selection:bg-[#F27D26] selection:text-white">
      <div className="atmosphere" />
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto glass-panel rounded-full px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#F27D26] to-orange-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold tracking-tight text-lg">Nexus</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-white/70">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#about" className="hover:text-white transition-colors">About</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="hidden md:block text-sm font-medium text-white/70 hover:text-white transition-colors">
              Log in
            </button>
            <button className="bg-white text-black px-5 py-2 rounded-full text-sm font-medium hover:bg-white/90 transition-colors">
              Get Started
            </button>
            <button className="md:hidden p-2">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="pt-40 pb-20 px-6 min-h-[90vh] flex flex-col items-center justify-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass-panel text-xs font-medium text-[#F27D26] mb-8"
          >
            <span className="w-2 h-2 rounded-full bg-[#F27D26] animate-pulse" />
            Introducing Nexus 2.0
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
            className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter max-w-5xl mx-auto leading-[0.9] mb-8"
          >
            Привет! Я Никита Чендев. <br className="hidden md:block" />
            Создаю <span className="text-gradient-accent italic font-serif pr-4">потрясающие</span> сайты.
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto mb-12 font-light"
          >
            Рабочий сайт с нуля всего за 2–4 дня. А если и нужно, то и за 1 день!
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            className="flex flex-col sm:flex-row items-center gap-4"
          >
            <button className="w-full sm:w-auto px-8 py-4 bg-[#F27D26] hover:bg-[#ff8c3a] text-white rounded-full font-medium flex items-center justify-center gap-2 transition-all hover:scale-105 active:scale-95">
              Start Creating Free
              <ArrowRight className="w-4 h-4" />
            </button>
            <button className="w-full sm:w-auto px-8 py-4 glass-panel hover:bg-white/10 text-white rounded-full font-medium flex items-center justify-center gap-2 transition-all">
              <Play className="w-4 h-4" />
              Watch Demo
            </button>
          </motion.div>
        </section>

        {/* Marquee Section */}
        <section className="py-10 border-y border-white/5 overflow-hidden bg-black/20">
          <div className="marquee-track gap-16 items-center">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="flex gap-16 items-center shrink-0">
                {['ACME CORP', 'GLOBAL INC', 'NEXUS', 'QUANTUM', 'STELLAR', 'VERTEX'].map((brand, j) => (
                  <span key={j} className="text-2xl font-bold tracking-widest text-white/20 uppercase font-serif italic">
                    {brand}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </section>

        {/* Features Bento Grid */}
        <section id="features" className="py-32 px-6 max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 text-gradient">
              Everything you need. <br />
              Nothing you don't.
            </h2>
            <p className="text-white/60 text-lg max-w-xl">
              A carefully curated set of tools designed to amplify your creativity without getting in your way.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Large Card */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="md:col-span-2 glass-panel rounded-3xl p-8 md:p-12 relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#F27D26]/20 rounded-full blur-[80px] -mr-20 -mt-20 transition-opacity group-hover:opacity-100 opacity-50" />
              <Zap className="w-10 h-10 text-[#F27D26] mb-6" />
              <h3 className="text-2xl md:text-3xl font-bold mb-4">Lightning Fast Performance</h3>
              <p className="text-white/60 max-w-md">
                Built on a custom rendering engine that processes complex scenes in milliseconds. 
                Never wait for a progress bar again.
              </p>
            </motion.div>

            {/* Square Card 1 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="glass-panel rounded-3xl p-8 relative overflow-hidden"
            >
              <Shield className="w-8 h-8 text-white/80 mb-6" />
              <h3 className="text-xl font-bold mb-3">Enterprise Security</h3>
              <p className="text-white/60 text-sm">
                Bank-grade encryption for all your creative assets. Your work belongs to you.
              </p>
            </motion.div>

            {/* Square Card 2 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="glass-panel rounded-3xl p-8 relative overflow-hidden"
            >
              <Globe className="w-8 h-8 text-white/80 mb-6" />
              <h3 className="text-xl font-bold mb-3">Global Collaboration</h3>
              <p className="text-white/60 text-sm">
                Work with your team in real-time, no matter where they are in the world.
              </p>
            </motion.div>

            {/* Wide Card */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="md:col-span-2 glass-panel rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-8"
            >
              <div>
                <h3 className="text-2xl font-bold mb-2">Ready to transform your workflow?</h3>
                <p className="text-white/60">Join thousands of creators already using Nexus.</p>
              </div>
              <button className="w-full md:w-auto px-6 py-3 bg-white text-black rounded-full font-medium hover:bg-white/90 transition-colors shrink-0">
                Get Started Now
              </button>
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 pt-20 pb-10 px-6 mt-20">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-10 mb-16">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-6 h-6 rounded-full bg-[#F27D26] flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-white" />
              </div>
              <span className="font-semibold tracking-tight">Nexus</span>
            </div>
            <p className="text-white/50 text-sm max-w-xs">
              Empowering creators to build the future of digital experiences.
            </p>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Product</h4>
            <ul className="space-y-3 text-sm text-white/50">
              <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Changelog</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Company</h4>
            <ul className="space-y-3 text-sm text-white/50">
              <li><a href="#" className="hover:text-white transition-colors">About</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
            </ul>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/10 text-xs text-white/40">
          <p>© 2026 Nexus Inc. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
